package ComandosDeRepeti��o;

//2) Escreva um algoritmo que calcule a soma dos n�meros de 1 a 15.

public class Exercicio2 {

	public static void main(String[] args) {

		int soma = 0;

		for (int i = 0; i <= 15; i++) {

			soma = soma + i;

		}

		System.out.println(soma);

	}
}
