package ComandosDeRepeti��o;

//Escreva um  algoritmo  que exiba 20 vezes  a mensagem  �Eu gosto  de estudar Algoritmos!�. 

public class Exercicio1 {

	public static void main(String[] args) {

		for (int i = 0; i < 20; i++) {

			System.out.println("Eu gosto  de estudar Algoritmos!");

		}

	}

}
